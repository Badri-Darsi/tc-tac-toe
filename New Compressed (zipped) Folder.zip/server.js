const express = require('express');
const bodyParser = require('body-parser');
const cors = require('cors');
const { v4: uuidv4 } = require('uuid');

const app = express();
const PORT = 3000;

// Middleware
app.use(bodyParser.json({ limit: '10mb' })); // To handle large photo data
app.use(cors());

// In-memory storage for cards
const cards = {};

// Endpoint to create a card
app.post('/create-card', (req, res) => {
    console.log('Received request to create card:', req.body);
    const { name1, name2, years, photo } = req.body;

    if (!name1 || !name2 || !years || !photo) {
        console.error('Missing fields in request body');
        return res.status(400).json({ error: 'All fields are required.' });
    }

    const cardId = uuidv4();
    cards[cardId] = { name1, name2, years, photo };

    console.log('Card created with ID:', cardId);
    res.json({ cardId });
});

// Endpoint to retrieve a card
app.get('/card/:id', (req, res) => {
    console.log('Received request to retrieve card with ID:', req.params.id);
    const cardId = req.params.id;
    const card = cards[cardId];

    if (!card) {
        console.error('Card not found for ID:', cardId);
        return res.status(404).json({ error: 'Card not found.' });
    }

    console.log('Card retrieved:', card);
    res.json(card);
});

// Start the server
app.listen(PORT, () => {
    console.log(`Server is running on http://localhost:${PORT}`);
});